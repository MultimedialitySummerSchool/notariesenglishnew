//
//  CommitUploadedFileRequest.h
//  WDNetworking
//
//  Copyright (c) 2012 Western Digital. All rights reserved.
//

#import "ElementRequest.h"

@class Element;

@interface CommitUploadedFileRequest : ElementRequest {
    NSDictionary *_responseDict;
    Element *_sourceElement;
    BOOL _attemptWithoutMtimeUpdate;
}

- (id)initWithElement:(OrionElement *)element source:(Element *)sourceElement withResponseDict:(NSDictionary *)dict;

@end
