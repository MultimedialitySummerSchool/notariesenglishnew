//
//  CommitUploadedFileRequest.m
//  WDNetworking
//
//  Copyright (c) 2012 Western Digital. All rights reserved.
//

#import "CommitUploadedFileRequest.h"

#import "OrionElement.h"
#import "NetworkManager.h"
#import "NSString+urlEscape.h"
#import "NSError+Extension.h"
#import "DeviceHTTPRequestOperationManager.h"

static NSString *commandPath = @"/api/1.0/rest/file";

@interface CommitUploadedFileRequest()

@property (nonatomic, retain) NSDictionary *responseDict;
@property (nonatomic, retain) Element *sourceElement;
@property (nonatomic) BOOL attemptWithoutMtimeUpdate;

@end

@implementation CommitUploadedFileRequest
@synthesize responseDict = _responseDict;
@synthesize sourceElement = _sourceElement;
@synthesize attemptWithoutMtimeUpdate = _attemptWithoutMtimeUpdate;

- (void)dealloc {
    [_responseDict release];
    [_sourceElement release];
    [super dealloc];
}
- (NSString *)url {
    NSMutableString *path = [NSMutableString new];
    [path appendString:commandPath];
    [path appendString:[[self.element.parentPath stringByAppendingPathComponent:[NSString stringWithFormat:@".%@", self.sourceElement.name]] urlEscapeFullPathIgnoreSlash]];
    return [path autorelease];
}

- (NSDictionary *)urlParameters {
    NSMutableDictionary *params = [[NSMutableDictionary alloc] initWithCapacity:3];
    [params setObject:@"json" forKey:@"format"];
    NSString *newPath = [[self.element.parentPath stringByAppendingPathComponent:self.element.name] urlEscapeFullPathIgnoreSlash];
    [params setObject:newPath forKey:@"new_path"];
  
    if (self.element.modifiedDate && !_attemptWithoutMtimeUpdate) {
        NSString *mTime = [NSString stringWithFormat:@"%f", [self.element.modifiedDate timeIntervalSince1970]];
        if (mTime.length > 0) {
            [params setObject:mTime forKey:@"mtime"];
        }
    }
    
    return [params autorelease];
}

- (NSString *)requestMethod {
    return kRequestMethodPUT;
}

- (NSString *)notificationString {
    return kElementUploadRequestFinished;
}

- (id)processResponse:(id)responseObject responseHeaders:(NSDictionary *)responseHeaders {
    NSArray *response = [[responseObject objectForKey:@"dir"] objectForKey:@"entry"];
    
    if (response.count > 0)
        return response;
    return nil;
}

- (NSDictionary *)responseDict:(NetworkResponse *)response {
    if (response.succeeded) {
        return self.responseDict;
    }
    return [super responseDict:response];
}

- (NSError *)processError:(NSError *)error response:(NSHTTPURLResponse *)response responseData:(NSData *)data {
    
    if (response.statusCode == 401) {
        return [error errorWithTitle:kElementRequestNoShareAccessTitle description:kElementRequestNoShareAccess errorCode:response.statusCode];
    }

    return [super processError:error response:response responseData:data];
}

- (void)sendResponse:(NetworkResponse *)response {
    if (response.succeeded || _attemptWithoutMtimeUpdate) {
        [super sendResponse:response];
    } else {
        //If the first commit request fails, we will attempt again without the mtime param.
        //Firmware ITR 89159 prevents a successful rename for files with some unicode paths if the file mtime is also updated.
        //The user will loose the original modified date but the uploaded hidden data move will succeed.
        CommitUploadedFileRequest *commitUpload = [[CommitUploadedFileRequest alloc] initWithElement:self.element source:_sourceElement withResponseDict:self.responseDict];
        commitUpload.attemptWithoutMtimeUpdate = YES;
        DeviceHTTPRequestOperationManager *manager = (DeviceHTTPRequestOperationManager *)self.manager;
        [manager queueRequest:commitUpload asContinuationOf:self];
        [commitUpload release];
    }
}

- (id)initWithElement:(OrionElement *)element source:(Element *)sourceElement withResponseDict:(NSDictionary *)dict {

    self = [super initWithElement:element];
	if (self != nil) {

        self.attemptWithoutMtimeUpdate = NO;
        self.sourceElement = sourceElement;
        self.responseDict = dict;
    }
    
	return self;
}

@end
