//
//  UploadFileChunkRequest.h
//  WDNetworking
//
//  Copyright (c) 2012 Western Digital. All rights reserved.
//

#import "ElementRequest.h"

@class Element;

@interface UploadFileChunkRequest : ElementRequest {
    @private
    unsigned long long int _uploadChunkOffset;
    unsigned long long int _chunkLength;
    Element *_sourceElement;

}

- (id)initWithElement:(OrionElement *)element source:(Element *)sourceElement;
- (id)initWithElement:(OrionElement *)element source:(Element *)sourceElement offset:(unsigned long long int)offset;
- (id)initWithElement:(OrionElement *)element source:(Element *)sourceElement responseBlock:(ResponseBlock)block;
- (id)initWithElement:(OrionElement *)element source:(Element *)sourceElement offset:(unsigned long long int)offset responseBlock:(ResponseBlock)block;

@end
