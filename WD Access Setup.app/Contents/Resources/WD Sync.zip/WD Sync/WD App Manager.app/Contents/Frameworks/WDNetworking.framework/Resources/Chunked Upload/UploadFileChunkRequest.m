//
//  UploadFileChunkRequest.m
//  WDNetworking
//
//  Copyright (c) 2012 Western Digital. All rights reserved.
//

#import "UploadFileChunkRequest.h"

#import "CommitUploadedFileRequest.h"

#import "OrionElement.h"
#import "OrionDevice.h"
#import "NetworkManager.h"
#import "NSString+urlEscape.h"
#import "NSError+Extension.h"
#import "DeviceHTTPRequestOperationManager.h"
#import "BaseHTTPRequestOperation.h"
#import "CorePreferences.h"

#define kByteChunkLAN   (64 * 1024 * 1024)
#define kByteChunkWAN  (4 * 1024 * 1024)

#define kHttpPostMimeBoundary @"axx4a420ce076f81689c7fawd"

static NSString *commandPath = @"/api/1.0/rest/file_contents";

@interface UploadFileChunkRequest ()

@property (nonatomic) unsigned long long int uploadChunkOffset;
@property (nonatomic) unsigned long long int chunkLength;

@property (nonatomic, retain) Element *sourceElement;

@end

@implementation UploadFileChunkRequest
@synthesize sourceElement = _sourceElement;
@synthesize uploadChunkOffset = _uploadChunkOffset;
@synthesize chunkLength = _chunkLength;

- (void)dealloc {
    [_sourceElement release];
    [super dealloc];
}

- (NSString *)url {
    NSMutableString *path = [NSMutableString new];
    [path appendString:commandPath];
    [path appendString:[[self.element.parentPath stringByAppendingPathComponent:[NSString stringWithFormat:@".%@", self.sourceElement.name]] urlEscapeFullPathIgnoreSlash]];
    return [path autorelease];
}

- (NSDictionary *)urlParameters {
    return @{@"format" : @"json",
             @"dummyoffset" : [NSString stringWithFormat:@"%llu",self.uploadChunkOffset]};
}

- (NSString *)requestMethod {
    return kRequestMethodPOST;
}

- (NSDictionary *)requestHeaders {
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@",kHttpPostMimeBoundary];
    return @{@"Content-Type" : contentType};
}

- (NSString *)notificationString {
    return kElementUploadRequestFinished;
}

- (BOOL)shouldExecuteAsBackgroundTask {
    return YES;
}
- (void)operationWillRun:(BaseHTTPRequestOperation *)operation {
//    NSLog(@"<%@:%@:%d><%d:%d:%d>", NSStringFromClass([self class]), NSStringFromSelector(_cmd), __LINE__, operation.isCancelled, operation.isExecuting, operation.isFinished);

    __block UploadFileChunkRequest *blockSelf = self;
    [operation setUploadProgressBlock:^(NSUInteger bytesWritten, long long totalBytesWritten, long long totalBytesExpectedToWrite) {
        unsigned long long overallBytesUploaded = self.uploadChunkOffset + totalBytesWritten;
        float percentComplete = overallBytesUploaded / [blockSelf.element.size doubleValue];
        [blockSelf.element setUploadProgress:percentComplete];
    }];
}

- (id)processResponse:(id)responseObject responseHeaders:(NSDictionary *)responseHeaders {
//TODO: CLEANUP incorrect assumption about format, but not used in app?
//this isn't the correct structure for a MBL Duo, is the response needed?
//this isn't the correct structure for a Sequoia, is the response needed?
    
//    Response:
//    {
//        "file_contents" =     {
//            status = success;
//        };
//    }
    NSArray *response = [[responseObject objectForKey:@"dir"] objectForKey:@"entry"];
    if ([[CorePreferences sharedCorePreferences] allowDebugLogging]) {
        LogDebug(@"Uploaded Chunk Done: %llu", _uploadChunkOffset + _chunkLength);
    }
    if (response.count > 0) {
        return response;
    }
    
    return nil;
}

- (NSError *)processError:(NSError *)error response:(NSHTTPURLResponse *)response responseData:(NSData *)data {
    
    if (response.statusCode == 401) {
        return [error errorWithTitle:kElementRequestNoShareAccessTitle description:kElementRequestNoShareAccess errorCode:response.statusCode];
    } else if (response.statusCode == 403) {
        return [error errorWithTitle:NSLocalizedString(@"Upload Error", @"") description:NSLocalizedString(@"You do not have permission to upload one or more selected files", @"") errorCode:response.statusCode];
    }
    
    return [super processError:error response:response responseData:data];
}

- (id)initWithElement:(OrionElement *)element source:(Element *)sourceElement {

    return [self initWithElement:element source:sourceElement offset:0];
}

- (id)initWithElement:(OrionElement *)element source:(Element *)sourceElement offset:(unsigned long long)offset {
    
    self = [self initWithElement:element];
    if (self != nil) {
        self.sourceElement = sourceElement;
        self.uploadChunkOffset = offset;
    }
    
    return self;
}

- (id)initWithElement:(OrionElement *)element source:(Element *)sourceElement responseBlock:(ResponseBlock)block {
    
    return [self initWithElement:element source:sourceElement offset:0 responseBlock:block];
}

- (id)initWithElement:(OrionElement *)element source:(Element *)sourceElement offset:(unsigned long long)offset responseBlock:(ResponseBlock)block {
    
    self = [self initWithElement:element responseBlock:block];
    if (self != nil) {
        self.sourceElement = sourceElement;
        self.uploadChunkOffset = offset;
    }
    
    return self;
}


- (NSData *)httpBodyData {

    NSMutableData *data = [[NSMutableData alloc] init];
    [data appendData:[self utf8Data:[NSString stringWithFormat:@"\r\n\r\n--%@\r\n", kHttpPostMimeBoundary]]];
    [data appendData:[self utf8Data:@"Content-Disposition: form-data; name=\"rest_method\"\r\n\r\n"]];
    [data appendData:[self utf8Data:@"PUT"]];

    [data appendData:[self utf8Data:[NSString stringWithFormat:@"\r\n--%@\r\n", kHttpPostMimeBoundary]]];
    [data appendData:[self utf8Data:@"Content-Disposition: form-data; name=\"http_range\"\r\n\r\n"]];
    
    if ([(OrionDevice *)self.element.device isInLan]) {
        _chunkLength = kByteChunkLAN;
    } else {
        _chunkLength = kByteChunkWAN;
    }
    
    if (_uploadChunkOffset + _chunkLength > [self.sourceElement.size unsignedLongLongValue]) {
        _chunkLength = ([self.sourceElement.size unsignedLongLongValue] - _uploadChunkOffset);
    }
    
    NSFileHandle *fileHandle = [NSFileHandle fileHandleForReadingAtPath:self.sourceElement.filePath];
    if (!fileHandle) {
        NSLog(@"%@:file not found : %@!", [self className], self.sourceElement.filePath);
    }
    [fileHandle seekToFileOffset:_uploadChunkOffset];
    NSData *chunkData = [fileHandle readDataOfLength:(unsigned)_chunkLength];
    
    [data appendData:[self utf8Data:[NSString stringWithFormat:@"%llu-0",_uploadChunkOffset]]];
    [data appendData:[self utf8Data:[NSString stringWithFormat:@"\r\n--%@\r\n", kHttpPostMimeBoundary]]];
    
    NSString *filenameString = [NSString stringWithFormat:@"Content-Disposition: form-data; name=\"file\"; filename=\"%@\"\r\n", self.sourceElement.name];
    [data appendData:[self utf8Data:filenameString]];

    NSString *mimeType = [Request mimeTypeForFileAtPath:self.sourceElement.filePath];
    [data appendData:[self utf8Data:[NSString stringWithFormat:@"Content-Type: %@\r\n\r\n", mimeType]]];
    [data appendData:chunkData];
    [data appendData:[self utf8Data:[NSString stringWithFormat:@"\r\n--%@--\r\n",kHttpPostMimeBoundary]]];

    return [data autorelease];
}

- (void)sendResponse:(NetworkResponse *)response {
    
    if (response.succeeded) {
        if (([self.sourceElement.size unsignedLongLongValue] > _chunkLength + _uploadChunkOffset)) {
            UploadFileChunkRequest *nextChunk = [[UploadFileChunkRequest alloc] initWithElement:self.element source:self.sourceElement offset:_uploadChunkOffset + _chunkLength];
            [self continueWithRequest:nextChunk];
            [nextChunk release];
        } else {
            CommitUploadedFileRequest *commitUpload = [[CommitUploadedFileRequest alloc] initWithElement:self.element source:_sourceElement withResponseDict:[self responseDict:response]];
            [self continueWithRequest:commitUpload];
            [commitUpload release];
        }
    } else {
        [super sendResponse:response];
    }
}

#pragma mark - Helper
- (void)continueWithRequest:(Request *)request {
    DeviceHTTPRequestOperationManager *manager = (DeviceHTTPRequestOperationManager *)self.manager;
    [manager queueRequest:request asContinuationOf:self];
}

- (NSData *)utf8Data:(NSString *)dataString {
    return [dataString dataUsingEncoding:NSUTF8StringEncoding];
}

@end
