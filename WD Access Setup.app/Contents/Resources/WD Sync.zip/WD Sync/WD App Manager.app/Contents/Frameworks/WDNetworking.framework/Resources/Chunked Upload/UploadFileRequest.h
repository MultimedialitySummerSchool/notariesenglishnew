//
//  UploadFileRequest.h
//  WDNetworking
//
//  Created by Kevin Gudgeirsson on 11/23/11.
//  Copyright (c) 2011 Western Digital. All rights reserved.
//

#import "ElementRequest.h"

@class Element;

@interface UploadFileRequest : ElementRequest {
    Element *_sourceElement;
}

- (id)initWithElement:(OrionElement *)element source:(Element *)source;
- (id)initWithElement:(OrionElement *)element source:(Element *)source responseBlock:(ResponseBlock)block;
@end
