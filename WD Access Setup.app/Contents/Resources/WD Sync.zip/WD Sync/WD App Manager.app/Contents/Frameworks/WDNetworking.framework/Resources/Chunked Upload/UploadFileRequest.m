//
//  UploadFileRequest.m
//  WDNetworking
//
//  Created by Kevin Gudgeirsson on 11/23/11.
//  Copyright (c) 2011 Western Digital. All rights reserved.
//

#import "UploadFileRequest.h"

#import "CommitUploadedFileRequest.h"
#import "UploadFileChunkRequest.h"
#import "UploadVerifyResumableRequest.h"

#import "DeviceHTTPRequestOperationManager.h"
#import "OrionElement.h"
#import "NetworkManager.h"
#import "NSString+urlEscape.h"

static NSString *commandPath = @"/api/1.0/rest/file";

@interface UploadFileRequest()

@property (nonatomic, retain) Element *sourceElement;

@end

@implementation UploadFileRequest
@synthesize sourceElement = _sourceElement;
- (void)dealloc {
    [_sourceElement release];
    [super dealloc];
}

- (NSString *)url {
    NSMutableString *path = [NSMutableString new];
    [path appendString:commandPath];
    [path appendString:[[self.element.parentPath stringByAppendingPathComponent:[NSString stringWithFormat:@".%@", self.sourceElement.name]] urlEscapeFullPathIgnoreSlash]];
    return [path autorelease];
}

- (NSDictionary *)urlParameters {
    return @{@"format" : @"json"};
}

- (NSString *)notificationString {
    return kElementUploadRequestFinished;
}

- (id)processResponse:(id)responseObject responseHeaders:(NSDictionary *)responseHeaders {
    return [responseObject objectForKey:@"file"];
}

- (id)initWithElement:(OrionElement *)element source:(Element *)source {

    self = [self initWithElement:element];
    if (self != nil) {
        self.sourceElement = source;
    }    
    return self;
}

- (id)initWithElement:(OrionElement *)element source:(Element *)source responseBlock:(ResponseBlock)block {
    
    self = [self initWithElement:element responseBlock:block];
    if (self != nil) {
        self.sourceElement = source;
    }
    return self;
}

- (void)sendResponse:(NetworkResponse *)response {
    if (response.cancelled) {
        [super sendResponse:response];
        return;
    }
    
    unsigned long long currentFileSize = 0;
    
    if (response.succeeded) {
        id payload = response.payload;
        if (payload != nil && [payload objectForKey:@"size"] != nil) {
            currentFileSize = [[payload objectForKey:@"size"] unsignedLongLongValue];
        }
    }
    
    DeviceHTTPRequestOperationManager *manager = (DeviceHTTPRequestOperationManager *)self.manager;
    if (currentFileSize >= kVerifyResumableNumBytes) {
        
        //verify end of data matches to continue upload from last location
        UploadVerifyResumableRequest *verifyResumable = [[UploadVerifyResumableRequest alloc] initWithElement:self.element uploadedSize:currentFileSize source:_sourceElement];
        [manager queueRequest:verifyResumable asContinuationOf:self];
        [verifyResumable release];
    } else {
        
        //start upload from offset 0
        UploadFileChunkRequest *firstChunk = [[UploadFileChunkRequest alloc] initWithElement:self.element source:_sourceElement];
        [manager queueRequest:firstChunk asContinuationOf:self];
        [firstChunk release];
    }
}

@end
