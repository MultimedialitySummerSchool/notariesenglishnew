//
//  UploadVerifyResumableRequest.h
//  WDNetworking
//
//  Copyright (c) 2012 Western Digital. All rights reserved.
//

#define kVerifyResumableNumBytes 512

#import "ElementRequest.h"

@class Element;

@interface UploadVerifyResumableRequest : ElementRequest {
    @private
    Element *_sourceElement;
    unsigned long long _uploadedSize;

}

- (id)initWithElement:(OrionElement *)element uploadedSize:(unsigned long long)uploadedSize source:(Element *)sourceElement;
- (id)initWithElement:(OrionElement *)element uploadedSize:(unsigned long long)uploadedSize source:(Element *)sourceElement responseBlock:(ResponseBlock)block;
- (void)processResponse:(NetworkResponse *)response responseBlock:(ResponseBlock)firstChunkBlock;
@end
