//
//  UploadVerifyResumableRequest.m
//  WDNetworking
//
//  Copyright (c) 2012 Western Digital. All rights reserved.
//

#import "UploadVerifyResumableRequest.h"

#import "UploadFileChunkRequest.h"

#import "OrionElement.h"
#import "NSString+urlEscape.h"
#import "DeviceHTTPRequestOperationManager.h"

static NSString *commandPath = @"/api/1.0/rest/file_contents";

@interface UploadVerifyResumableRequest()

@property (nonatomic, retain) Element *sourceElement;
@property (nonatomic) unsigned long long uploadedSize;

@end

@implementation UploadVerifyResumableRequest
@synthesize sourceElement = _sourceElement;
@synthesize uploadedSize = _uploadedSize;

- (void)dealloc {
    [_sourceElement release];
    [super dealloc];
}

- (NSString *)url {
    NSMutableString *path = [NSMutableString new];
    [path appendString:commandPath];
    [path appendString:[[self.element.parentPath stringByAppendingPathComponent:[NSString stringWithFormat:@".%@", self.sourceElement.name]] urlEscapeFullPathIgnoreSlash]];
    return [path autorelease];
}

- (NSDictionary *)urlParameters {
    NSString *range = [NSString stringWithFormat:@"bytes=%llu-%llu", [self dataOffset], self.uploadedSize - 1];
    return @{@"http_range" : range };
}

- (NSDictionary *)requestHeaders {
    NSString *range = [NSString stringWithFormat:@"bytes=%llu-%llu", [self dataOffset], self.uploadedSize - 1];
    return @{@"Range" : range};
}

- (ResponseType)responseType {
    return kResponseTypeData;
}

- (id)initWithElement:(OrionElement *)element uploadedSize:(unsigned long long)uploadedSize source:(Element *)sourceElement {
    self = [self initWithElement:element];
    if (self != nil) {
        self.sourceElement = sourceElement;
        self.uploadedSize = uploadedSize;
    }
    return self;
}
- (id)initWithElement:(OrionElement *)element uploadedSize:(unsigned long long)uploadedSize source:(Element *)sourceElement responseBlock:(ResponseBlock)block {
    self = [self initWithElement:element];
    if (self != nil) {
        self.sourceElement = sourceElement;
        self.uploadedSize = uploadedSize;
    }
    return self;
}

- (void)processResponse:(NetworkResponse *)response responseBlock:(ResponseBlock)firstChunkBlock {
    unsigned long long offset = 0;

    if (response.succeeded) {

        NSFileHandle *fileHandle = [NSFileHandle fileHandleForReadingAtPath:self.sourceElement.filePath];
        [fileHandle seekToFileOffset:[self dataOffset]];
        NSData *actualFileData = [fileHandle readDataOfLength:kVerifyResumableNumBytes];

        if ([response.payload isEqualToData:actualFileData]) {
            offset = self.uploadedSize;
        }
    }

    UploadFileChunkRequest *firstChunk = [[UploadFileChunkRequest alloc] initWithElement:self.element source:_sourceElement offset:offset];
    firstChunk.block = firstChunkBlock;
    DeviceHTTPRequestOperationManager *manager = (DeviceHTTPRequestOperationManager *)self.manager;
    [manager queueRequest:firstChunk asContinuationOf:self];
}

- (void)sendResponse:(NetworkResponse *)response {
    unsigned long long offset = 0;
    
    if (response.succeeded) {
        
        NSFileHandle *fileHandle = [NSFileHandle fileHandleForReadingAtPath:self.sourceElement.filePath];
        [fileHandle seekToFileOffset:[self dataOffset]];
        NSData *actualFileData = [fileHandle readDataOfLength:kVerifyResumableNumBytes];
        
        if ([response.payload isEqualToData:actualFileData]) {
            offset = self.uploadedSize;
        }
    }
    
    UploadFileChunkRequest *firstChunk = [[UploadFileChunkRequest alloc] initWithElement:self.element source:_sourceElement offset:offset];
    DeviceHTTPRequestOperationManager *manager = (DeviceHTTPRequestOperationManager *)self.manager;
    [manager queueRequest:firstChunk asContinuationOf:self];
    [firstChunk release];
}

- (unsigned long long)dataOffset {

    return self.uploadedSize - (unsigned long long)kVerifyResumableNumBytes;
}

@end
