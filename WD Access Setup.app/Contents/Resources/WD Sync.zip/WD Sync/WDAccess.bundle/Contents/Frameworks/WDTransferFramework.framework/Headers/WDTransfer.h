//
//  WDTransfer.h
//  WDTransferFramework
//
//  Created by Ganesh Krishna on 10/26/14.
//  Copyright (c) 2014 Western Digital. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "WDTransferDragDropSourceView.h"

@protocol WDTransferDelegate <NSObject>

@optional

-(void) fileTransferStatusUpdate:(BOOL)isFileTransferCompleted isFileTransferFailed:(BOOL)isFileTransferFailed isFileTransferCancelled:(BOOL)isFileTransferCancelled isFileTransferPaused:(BOOL)isFileTransferPaused isDeviceReachable:(BOOL)isDeviceReachable progressStatus:(NSString*)progressStatus subProgressStatus:(NSString*)subProgressStatus;
-(void) backToQuickViewFromWDTransfer;
-(void) cancelledWDTransfer;

@end


@interface WDTransfer : NSObject <NSApplicationDelegate, NSWindowDelegate, NSFileManagerDelegate,WDTransferDragDropSourceViewDelegate>
{
    BOOL    delegateRespondsToFileTransferStatusUpdate;
}

@property (weak, nonatomic) id <WDTransferDelegate> delegatedObject;


/*!
 initWithDevice:
 @description initializes the WD Transfer framework with device (NAS/DAS) dictionary
 @param device (NAS/DAS) dictionary (Example: NSDictionary deviceType=NAS/DAS deviceInfo=NAS details/DAS details)
 @result returns an object to the WD Transfer framework. The frameworks responsibility is to transfer the selected files to NAS/DAS.
 */
-(id) initWithDevice:(NSDictionary*)deviceDict;


/*!
 setDelegate:
 @description sets the delegate to WD Transfer
 @param class object which you want to set the delegate as
 @result sets your class object as the delegate
 */
-(void) setDelegate:(id<WDTransferDelegate>)object;


/*!
 startFileTransfer:
 @description starts WD Transfer
 @result fileTransferStatusUpdate callback provides the status of file transfer
 */
-(void) startFileTransfer;


/*!
 resumeFileTransferAfterRestart:
 @description resumes WD Transfer after computer restart or app restart
 @result fileTransferStatusUpdate callback provides the status of file transfer
 */
-(void) resumeFileTransferAfterRestart;


/*!
 showStatus:
 @description shows status of the current WD Transfer
 @result displays the status window
 */
-(void) showStatus;


/*!
 showErrors:
 @description shows all errors occured in the current WD Transfer
 @result displays an error window showing all current errors
 */
-(void) showErrors;


/*!
 terminateTransfer:
 @description terminateTransfer stops all file transfer
 @result stops the transfer
 */
-(void) terminateTransfer;


/*!
 discovereDevicesForTransfer:
 @description gets all discovered NAS and DAS devices
 @result discovereDevicesForTransfer method gets called from QuickView whenever there is a chnage in discovered devices
 */
-(void) discovereDevicesForTransfer:(NSDictionary*)discovereDevices;


/*!
 pauseTransfer:
 @description pauseTransfer gets called if transfer has to be paused
 @result pauses the transfer
 */
-(void) pauseTransfer;


/*!
 resumeTransfer:
 @description resumeTransfer gets called to resume transfer
 @result resumes the transfer
 */
-(void) resumeTransfer;


/*!
 cancelTransfer:
 @description cancelTransfer cancels all file transfer
 @result cancels the transfer
 */
-(void) cancelTransfer;


@end