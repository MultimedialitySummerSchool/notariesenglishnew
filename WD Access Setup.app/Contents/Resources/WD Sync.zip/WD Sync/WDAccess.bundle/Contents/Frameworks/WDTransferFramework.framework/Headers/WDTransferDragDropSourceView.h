//
//  WDTransferDragDropSourceView.h
//  WDTransferFramework
//
//  Created by Ganesh Krishna on 10/26/14.
//  Copyright (c) 2014 Western Digital. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@protocol WDTransferDragDropSourceViewDelegate <NSObject>

@optional

- (NSDragOperation)draggingEntered:(id <NSDraggingInfo>)sender;
- (void)draggingExited:(id <NSDraggingInfo>)sender;
- (BOOL)prepareForDragOperation:(id <NSDraggingInfo>)sender;
- (BOOL)performDragOperation:(id <NSDraggingInfo>)sender;
- (void)concludeDragOperation:(id <NSDraggingInfo>)sender;

@end

@interface WDTransferDragDropSourceView : NSView
{
	id      dragDropDelegate;
    BOOL    delegateRespondsToFileTransferDragDropSourceView;
}

-(void)setDelegate:(id)object;

@end