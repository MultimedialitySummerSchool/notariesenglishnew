//
//  WDButton.h
//  WD Drive Utility
//
//  Created by Bob Hahn on 11/10/14.
//  Copyright (c) 2014 Western Digital. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface WDButton : NSButton
{
    NSColor *titleColor;
    NSFont *titleFont;
}

@property (readwrite,retain) NSColor *titleColor;
@property (readwrite,retain) NSFont *titleFont;

- (id)initWithCoder:(NSCoder *)inCoder;
- (void) setStringValue: (NSString *) stringValue;
- (void) setTitle: (NSString *) stringValue;

@end

//@interface WDButtonCell : NSButtonCell
//{
//    
//}
//
//- (NSRect) drawTitle:(NSAttributedString *)title withFrame:(NSRect)frame inView:(NSView *)controlView;
//
//@end
