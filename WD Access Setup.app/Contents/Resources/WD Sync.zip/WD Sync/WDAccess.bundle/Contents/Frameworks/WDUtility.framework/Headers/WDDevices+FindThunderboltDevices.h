//
//  findThunderboltDevices.h
//  DriveUnlock
//
//  Created by Bob on 3/9/09.
//  Copyright © 2014 Western Digital Technologies, Inc. All rights reserved.
//

#import "WDDevices.h"

@interface WDDevices (findThunderboltDevices)

- (id) registerNotificationsForTBPIDS: (NSArray *)supportedPids;

void TBDeviceAddedCallback(void* refCon, io_iterator_t iter);
void TBDeviceRemovedCallback(void* refCon, io_iterator_t iter);

void SESDeviceAddedCallback(void* refCon, io_iterator_t iterator);
void SESDeviceRemovedCallback(void* refCon, io_iterator_t iterator);

@end
