//
//  WDTBRAIDDevice.h
//  WDUtility
//
//  Created by Bob Hahn on 12/3/13.
//
//

#import <WDUtility/WDDevice.h>
#import "WDDiskHWRaid.h"
#import "WDDiskSWRaid.h"

@interface WDTBDevice : WDDevice
{
//  io_service_t    AppleAHCInterface;			// SWRAID - Start the search for disk drives here.
    int             mThunderboltPortNumber;     //
//    int             mRAIDMode;
//    int             mRAIDStatus;
//    NSString *		mRAIDSetName;
//    NSString *		mRAIDFormat;
//    NSNumber *		mRAIDRebuildProgress;
}

//@property (readwrite,assign) io_service_t			AppleAHCInterface;
@property (readwrite,assign) int					mThunderboltPortNumber;
//@property (readwrite,assign) int            mRAIDMode;
//@property (readwrite,copy) NSString *		mRAIDSetName;
//@property (readwrite,assign) int            mRAIDStatus;
//@property (readwrite,copy) NSString *		mRAIDFormat;
//@property (readwrite,copy) NSNumber *		mRAIDRebuildProgress;

- (id) initWithPid: (unsigned int)productID;

- (io_service_t) populateDeviceInformation;
- (io_service_t) populateDriveInformation;

@end
